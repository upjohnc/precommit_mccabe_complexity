"""pre-commit hook for checking mccabe complexity"""

__version__ = '0.9.3'
