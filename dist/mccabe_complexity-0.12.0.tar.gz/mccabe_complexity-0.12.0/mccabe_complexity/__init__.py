"""pre-commit hook for checking mccabe complexity"""

__version__ = '0.12.0'
